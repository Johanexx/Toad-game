
document.getElementById('piedra').addEventListener('click', function() {
    play('piedra');
});

document.getElementById('papel').addEventListener('click', function() {
    play('papel');
});

document.getElementById('tijera').addEventListener('click', function() {
    play('tijera');
});

function play(tu) {
    var moves = ['piedra', 'papel', 'tijera'];
    var computerMove = moves[Math.floor(Math.random() * moves.length)];

    var result;
    if (tu === computerMove) {
        result = "empateeeee!";
    } else if ((tu === 'piedra' && computerMove === 'tijera') ||
               (tu === 'papel' && computerMove === 'piedra') ||
               (tu === 'tijera' && computerMove === 'papel')) {
        result = "ganasteee";
    } else {
        result = "paila, la computadora gano";
    }

    document.getElementById("result").innerText = " elegiste " + tu + ". la cumputadora eligio  " + computerMove + ". " + result;
}
