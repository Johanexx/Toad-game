let Player;
let Console;
function Aleatoria() {
    return Math.ceil(Math.random()*3)
}
jugador= prompt("Empezemos, digite - 1:piedra - 2:papel - 3:tijera")
pc=Aleatoria();
function Eleccion(jugadiña){
    let resultado
    if(jugadiña==1){
        resultado= "Piedra💎"
    }else if(jugadiña==2){
        resultado= "Papel🧻"
    }else if(jugadiña==3){
        resultado= "Tijera✂️"
    }else
        resultado= "digita bien crack"
    return resultado
    }
    if(jugador<=3){
alert("tu elegiste: "+Eleccion(jugador))
alert("la computadora eligió: "+Eleccion(pc))
}else if(jugador>3){
alert("escribe bien")
}
if (jugador== pc){
    alert("Empataron, nadie gana")
}else if(jugador==1 && pc==3){
    alert("ganaste, sos un crack")
}else if(jugador==2 && pc==1){
    alert("ganaste, sos un crack")
}else if(jugador==3 && pc==2){
    alert("ganaste, sos un crack")

 }else if(jugador>=4 && pc==1){
     alert("no sabes leer princesa?😔🥺😹🫵🫵")
 }else if(jugador>=4 && pc==2){
     alert("no sabes leer princesa?😔🥺😹🫵🫵")
}else if(jugador>=4 && pc==3){
     alert("no sabes leer princesa?😔🥺😹🫵🫵")
}else {
    alert("perdiste, sos un tonto.")
}


